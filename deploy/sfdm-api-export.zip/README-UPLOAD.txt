Upload to sfdm.xyz (cPanel File Manager)
=====================================

1. Log in to cPanel → File Manager
2. Open: public_html/api/   (same folder as api.php and db_connect.php)
3. Upload this file:
   - export_for_supabase.php  (from this folder)

You do NOT need to replace functions.php if you use the self-contained export file above.

4. Test in browser:
   https://sfdm.xyz/api/export_for_supabase.php?import_secret=madrasha-supabase-import

   Expected: JSON starting with {"status":"success","counts":{...

5. On your PC, run full import:
   cd web
   npm run import:legacy
